// ACTION TYPE
export const ADD_RESTAURANT = "ADD_ADD_RESTAURANT";

// DISPATCHER -- ACITON OBJECT
export const addRestaurant = (value) => ({type: ADD_RESTAURANT, payload: value});



