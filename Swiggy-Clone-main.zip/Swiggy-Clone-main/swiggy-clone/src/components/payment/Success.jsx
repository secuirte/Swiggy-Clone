

export const Successful = () => {

    return (
        <>
        <img  src="https://fcs3pub.s3.amazonaws.com/photo-book/images/payment/success.gif" alt="" />
        </>
    )
}