export const Coupons = [
    {
       icon: "https://cdn2.iconfinder.com/data/icons/social-icons-color/512/paytm-512.png",
       code: "PAYTMSAVE",
       discount:"Get assured cashback up to ₹100 using Paytm",
       cashback:"Cashback up to ₹100 on the items total above ₹399"
    },
    {
        icon: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/yzoezidvgzkojdhcwglu",
        code: "ICICI150",
        discount:"Get 20% discount using ICICI Bank Cards",
        cashback:"Maximum discount up to ₹150 on orders above ₹600"
     },
     {
        icon: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/pfwkiphk0bio21jclhbt",
        code: "CITIFOODIE",
        discount:"Get 15% discount using Citi Bank Cards",
        cashback:"Maximum discount up to ₹300 on orders above ₹1200"
     },
     {
        icon: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/pfwkiphk0bio21jclhbt",
        code: "CITIWORLD",
        discount:"Get 30% discount using Citi Bank World Debit Cards",
        cashback:"Maximum discount up to ₹600 on orders above ₹1200"
     },
     {
        icon: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/dj0rvucmtyg1nj0h0lrx",
        code: "RUPAY100",
        discount:"Get 20% discount using RuPay Platinum Debit Cards",
        cashback:"Maximum discount up to ₹100 on orders above ₹400"
     },
     {
        icon: "https://cdn2.iconfinder.com/data/icons/social-icons-color/512/paytm-512.png",
        code: "PAYTMSAVE",
        discount:"Get assured cashback up to ₹100 using Paytm",
        cashback:"Maximum discount up to ₹600 on orders above ₹1200"
     },
     {
        icon: "https://cdn2.iconfinder.com/data/icons/social-icons-color/512/paytm-512.png",
        code: "PAYTMSAVE",
        discount:"Get assured cashback up to ₹100 using Paytm",
        cashback:"Maximum discount up to ₹600 on orders above ₹1200"
     },
     {
        icon: "https://cdn2.iconfinder.com/data/icons/social-icons-color/512/paytm-512.png",
        code: "PAYTMSAVE",
        discount:"Get assured cashback up to ₹100 using Paytm",
        cashback:"Maximum discount up to ₹600 on orders above ₹1200"
     },

]